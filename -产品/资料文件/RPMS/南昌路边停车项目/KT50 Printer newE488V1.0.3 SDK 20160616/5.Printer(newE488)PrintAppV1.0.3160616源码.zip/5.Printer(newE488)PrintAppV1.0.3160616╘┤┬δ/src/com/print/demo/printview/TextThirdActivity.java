package com.print.demo.printview;

import com.print.demo.R;
import utils.ApplicationContext;
import utils.preDefiniation.AlignType;
import utils.preDefiniation.Barcode1DHRI;
import utils.preDefiniation.BarcodeType;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class TextThirdActivity extends Activity {
	public Button fire;
	public Button move;
	public Button shopping;
	public ApplicationContext context;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_textapply);
		fire = (Button) findViewById(R.id.Button_fire);
		move = (Button) findViewById(R.id.button_movie);
		shopping = (Button) findViewById(R.id.Button_shopping);
		context = (ApplicationContext) getApplicationContext();
		move.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				 context.getObject().CON_PageStart(context.getState(),false,0,0);
				 context.getObject().ASCII_CtrlAlignType(context.getState(),
				 AlignType.AT_CENTER.getValue());
				 context.getObject().ASCII_PrintString(context.getState(),
				 1, 1, 1, 0, 0, "�𹤹���Ӱ��", "gb2312");
				 context.getObject().ASCII_CtrlFeedLines(context.getState(),1);
				 context.getObject().ASCII_CtrlReset(context.getState());
				 context.getObject().ASCII_CtrlPrintPosition(context.getState(),24,450);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "Ӱ��  ", "gb2312");
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "��ʵ����    ", "gb2312");
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "ʱ��  ", "gb2312");
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "2015��1��16��", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "      1�Ŵ���          ",
				 "gb2312");
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "12:18����", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "ӰƬ  ", "gb2312");
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "��ʱ����      ", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "      ���ݣ�������С��", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "��λ  ", "gb2312");
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "һ��01��      ", "gb2312");
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "Ʊ��  50Ԫ", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_CtrlReset(context.getState());
				 context.getObject().ASCII_CtrlPrintPosition(context.getState(),24,450);
				 context.getObject().ASCII_Print1DBarcode(context.getState(),
				 BarcodeType.BT_UPCA.getValue(), 2, 28,
				 Barcode1DHRI.BH_BLEW.getValue(), "123456789012");
				 context.getObject().ASCII_CtrlFeedLines(context.getState(),1);
				 context.getObject().ASCII_CtrlReset(context.getState());
				 context.getObject().CON_PageEnd(context.getState(),context.getPrintway());
			}
		});
		shopping.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				 context.getObject().CON_PageStart(context.getState(),false,0,0);
				 context.getObject().ASCII_CtrlAlignType(context.getState(),
				 AlignType.AT_CENTER.getValue());
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 1,0, 0, 0, "��ӭ����  ", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "��������  ", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_CtrlAlignType(context.getState(),
				 AlignType.AT_LEFT.getValue());
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "����Ա������Ա����", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "ʱ�䣺2015-01-01", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "----------------------------",
				 "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "��Ʒ����        ����      ����      ���",
				 "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0,
				 0,"����           2.00      1      2.00", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "----------------------------",
				 "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "�ϼ�:��100Ԫ", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "�Żݽ��:��90Ԫ", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "�绰��01062985019", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "��ַ��������ʵ����", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "лл�ݹˣ���ӭ�´ι��٣�", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_CtrlReset(context.getState());
				 context.getObject().CON_PageEnd(context.getState(),context.getPrintway());

			}
		});
		fire.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				 context.getObject().CON_PageStart(context.getState(),false,0,0);
//				 context.getObject().CON_SetPrintDirection(context.getState(),false,0,0);
				 context.getObject().ASCII_CtrlAlignType(context.getState(),
				 AlignType.AT_RIGHT.getValue());
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "���� ��", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_CtrlAlignType(context.getState(),
				 AlignType.AT_CENTER.getValue());
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 1, 0, 0, "�� ��  ��������> �� ��", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "Beijing         Wuhan",
				 "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "2015��02��16��01:01��   12��12������",
				 "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "��180.00Ԫ             �¿յ�Ӳ��",
				 "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_CtrlReset(context.getState());
				 context.getObject().ASCII_PrintString(context.getState(),0,
				 0, 0, 0, 0, "���޵��յ��γ�", "gb2312");
				 context.getObject().ASCII_CtrlPrintCRLF(context.getState(),1);
				 context.getObject().ASCII_Print2DBarcode(context.getState(),BarcodeType.BT_QRcode.getValue(),"123456789",8,76,2);
				 context.getObject().ASCII_CtrlReset(context.getState());
				 context.getObject().CON_PageEnd(context.getState(),context.getPrintway());
			}
		});
	}
}